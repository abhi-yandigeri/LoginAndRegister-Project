package com.fujitsu.loginandregister.controller;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fujitsu.loginandregister.DAO.UserRegistrationdao;
import com.fujitsu.loginandregister.model.User;

/**
 * Servlet implementation class UserRegistration
 */
@WebServlet("/UserRegistration")
public class UserRegistration extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserRegistrationdao dao;
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		int phone=Integer.parseInt(request.getParameter("phone"));
		String address=request.getParameter("address");
		Random random=new Random();
		
		int userID = random.nextInt(99);
		
		User newuser=new User(userID,username, password,phone,address);
		
		
		System.out.println("New User:" +newuser);
		
		//Database saving
		dao=new UserRegistrationdao();
		boolean result = dao.Registeruser(newuser);
		
		if(result)
		{
			System.out.println("User Registered Successfully");
		}
		else
			System.out.println("Internal Servor Error");
		
	}

}
