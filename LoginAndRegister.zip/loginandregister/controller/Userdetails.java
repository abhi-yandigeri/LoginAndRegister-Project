package com.fujitsu.loginandregister.controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fujitsu.loginandregister.DAO.UserdetailsDAO;
import com.fujitsu.loginandregister.model.User;

@WebServlet("/Userdetails")
public class Userdetails extends HttpServlet {

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserdetailsDAO dao=new UserdetailsDAO();
		ResultSet rs=dao.getDetails();
		User user;
		ArrayList arr = new ArrayList();
		try
		{
			while(rs.next())
			{
				//System.out.println(rs.getInt(1)+" "+rs.getString(2));
				//user=new User(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getString(5));
				//users.add(user);
				arr.add("id :" +(rs.getInt(1)));
				arr.add("username : "+rs.getString(2));
				arr.add("password : "+rs.getString(3));
				arr.add("phone : "+rs.getInt(4));
				arr.add("address : "+rs.getString(5));
				System.out.println("\n");
			}
			request.setAttribute("arr", arr);
			request.getRequestDispatcher("Admin.jsp").forward(request, response);
			for (int i=0;i<arr.size();i++)
				System.out.println(arr.get(i));
		}
			catch(Exception e)
		{
				e.printStackTrace();
		}
		System.out.println("end of dopost");
	}

}
