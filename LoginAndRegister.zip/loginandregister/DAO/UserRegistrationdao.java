package com.fujitsu.loginandregister.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.fujitsu.loginandregister.model.User;

public class UserRegistrationdao {
	public boolean Registeruser(User user)
	{
		System.out.println("Start of RegistrationDAO:: Registeruser");
		
		String url="jdbc:mysql://localhost:3306/student";
		String db_username="root";
		String db_password ="sahana@07";
		Connection con;
		PreparedStatement pstmt;
		
		String sql ="insert into user1 values(?,?,?,?,?)";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 con = DriverManager.getConnection(url,db_username,db_password);
			 pstmt = con.prepareStatement(sql);
			 
			 pstmt.setInt(1, user.getId());
			 pstmt.setString(2,user.getUsername());
			 pstmt.setString(3,user.getPassword());
			 pstmt.setInt(4, user.getPhoneno());
			 pstmt.setString(5, user.getAddress());
			 
			 int result = pstmt.executeUpdate();
			 if(result>0)
			 
				 return true;
				 
				return false;
			 
			 
		}catch (Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("Start of UserRegistrationDAO :: registerUser");
		return false;
		
	}
}
